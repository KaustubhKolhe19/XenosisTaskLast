package com.jts.websocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
