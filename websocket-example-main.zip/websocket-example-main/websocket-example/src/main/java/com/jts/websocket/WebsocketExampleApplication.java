package com.jts.websocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsocketExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsocketExampleApplication.class, args);
	}

}
