package com.jts.websocket.service;

public enum MsgType {
	CHAT,
	JOIN,
	LEAVE
}
